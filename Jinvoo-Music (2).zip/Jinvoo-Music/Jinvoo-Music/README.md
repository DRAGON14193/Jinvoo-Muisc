# OddMusic
OddMusic is an simple but fastest discord music bot.
# Info
Node version required: `16+`<br/>
Discordjs version `13.7.0`
# Features
1. Fast as light
2. Minimal looks
3. User friendly
4. Optimized with discord.js@13
# Getting started
1. Download this git then unpack it.
2. Now use `npm install` command (make sure to nodejs is installed before doing this)
3. Put your token into `./config/config.json` file
4. Now run the bot using `node .` command.
# Support
You might know to make a discord bot it's take a lot of time and effort to code. So, if you want i keep working on new discord bots projects you can donate me at least 1 dollar.<br/>
[Paypal me](https://paypal.me/sestro69)
# Credit
Creator [Sestro#4472](https://oddcoder.xyz/).<br/>
Inspired from [Groovy Bot](https://groovy.bot/)<br/>
Support server [Join us](https://discord.gg/7KtdeePrHV)<br/>
