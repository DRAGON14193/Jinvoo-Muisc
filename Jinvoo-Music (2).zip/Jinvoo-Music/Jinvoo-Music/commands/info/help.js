const { MessageEmbed } = require("discord.js");
module.exports = {
    name: "help",
    aliases: ["h"],
    description: "Show all of the Commands",
    run: async (client, message, args, prefix) => {
        return message.reply(`Here is a list of all of my Commands:
Note: want to know all the aliases of command then use **.a** or **.aliases** command.
**Music commands**
**.play** - Plays Music in your Voice Channel.
**.playskip** - Plays Music in your Voice Channel and skips to it.
**.playtop** - Plays Music in your Voice Channel and positions it to the queue top.
**.nowplaying** - Shows information about the current track.
**.pause** - Pauses the current Track.
**.resume** - Resumes the current, paused Track.
**.volume** - Changes the Volume of the Music.
**.stop** - Stops playing and cleares the Queue.
**.shuffle** - Shuffles (mixes) the Queue
**.seek** - Seeks to a specific Position (sec).
**.speed** - Changes the Speed of the Music.
**.skip** - Skips the current Track.
**.skipto** - Skips to a specific Track in the Queue.
**.forward** - Forwards for X (secs).
**.rewind** - Rewinds for X (secs).
**.join** - Joins a Voice Channel.
**.move** - Moves a Song in the Queue.
**.leave** - Leaves a Voice Channel and stops playing.
**.queue** - Show the current Queue-List.
**.remove** - Removes a specific Track from the Queue.
**.clearqueue** - Cleares the Queue.
**.queueloop** - Toggles the Queue-Loop.
**.trackloop** - Toggles the Track-Loop.
**.filter** - Applys/Removes Filters of the Queue.
**.bassboost** - Changes the Bassboost Level of the Music.
**Info commands**
**.help** - Show all of the Commands.
**.ping** - Show the Bot's ping.
**.uptime** - Show the Bot's uptime.`).catch(() => null);
    },
};